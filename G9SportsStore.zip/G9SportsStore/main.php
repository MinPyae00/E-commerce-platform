<?php
session_start();
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: main.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>G9SportsStore | Ecommerce Website Design</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- ✅ Font Awesome CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* extra CSS for menu icon */
        .menu-icon {
            font-size: 28px;
            cursor: pointer;
            margin-left: 10px;
            display: inline-block;
        }
        nav ul {
            list-style: none;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="index.html"><img src="images/logo1.jpg" width="300px"></a>
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="products.html">Products</a></li>
                        <li><a href="about.html">About</a></li>
                        <li><a href="">Contact</a></li>
                        <li><a href="account.html">Account</a></li>
                        <?php if (isset($_SESSION['username'])): ?>
                            <li><a href="main.php?logout=true">Logout</a></li>
                        <?php else: 
                                header("Location: login/login.php");
                                exit();
                        endif; ?>
                    </ul>
                </nav>
                <!-- Cart Icon -->
                <a href="cart.html"><img src="images/cart.png" width="30px" height="30px"></a>
                <!-- ✅ Font Awesome Menu Icon -->
                <i class="fa fa-bars menu-icon" onclick="menutoggle()"></i>
            </div>
            <div class="row">
                <div class="col-2">
                    <h1>G9Sports Accessories Store</h1>
                    <p>G9SportsStore Website is a Website where <br>you can buy sports equipment.
                        Sports equipment<br> manufactured by Computer Science is available<br> at G9SportsStore.
                        The store is located on <br>BhoneKyeeKyaung Kwae Road,East Dagon Township.<br>You can reach G9SportsStore
                        by YBS-24,25,30,117,128.
                    </p>
                    <a href="" class="btn">Explore Now &#10174;</a>
                </div>
                <div class="col-2">
                    <img src="images/logo3.png">
                </div>
            </div>
        </div>
    </div>


<!-------- sports categories -------->
    <div class="categories">
        <div class="small-container">

        </div>
        <div class="row">
            <div class="col-3">
                <img src="images/football25.jpg">
            </div>
            <div class="col-3">
                <img src="images/volleyball25.jpg">
            </div>
            <div class="col-3">
                <img src="images/basketball25.jpg">
            </div>
            <div class="col-3">
                <img src="images/badminton25.jpg">
            </div>
            <div class="col-3">
                <img src="images/tabletennis25.jpg">
            </div>
        </div>

    </div>
<!-------- Football products -------->
<section id="products">
    <div class="small-container">
        <h2 class="title">Football Products</h2>
        <div class="row">
            <div class="col-4">
                <a href="products-details.html"><img src="images/Footballjersey1.jpg"></a>
                <a href="products-details.html"><h4>Blue Jersey</h4></a>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>50,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/Football jersey3.jpg">
                <h4>White Jersey</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>45,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/football1.jpg">
                <h4>Football</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>95,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/footballsocks.jpg">
                <h4> Socks</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>19,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/footballgloves.jpg">
                <h4> Gloves</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>55,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/footballshoes.jpg">
                <h4> Shoes</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>170,000 MMK</p>
            </div>
        </div>
        <h2 class="title">Volleyball Products</h2>
        <div class="row">
            <div class="col-4">
                <img src="images/Volleyball1.jpg">
                <h4>Volleyball</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>30,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/vshirt.jpg">
                <h4> Jersey</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>25,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/vshoes.jpg">
                <h4> Shoes</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>75,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/vsocks.jpg">
                <h4> Socks</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>10,000 MMK</p>
            </div>
        </div>
        <h2 class="title">Table Tennis Products</h2>
        <div class="row">
            <div class="col-4">
                <img src="images/tableshirt.jpg">
                <h4> Jersey</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i cs="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>33,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/tableshoes.jpg">
                <h4>Shoes</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>125,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/tracket.jpg">
                <h4>Rackets</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>90,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/pball.jpg">
                <h4>Ping Pong Balls</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>25,000 MMK</p>
            </div>
        </div>
        <h2 class="title">Badminton Products</h2>
        <div class="row">
            <div class="col-4">
                <img src="images/badshirt.jpg">
                <h4>Jersey</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>55,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/brackets.jpg">
                <h4>Rackets</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>130,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/bshoes.jpg">
                <h4>Shoes</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
            </div>
            <p>210,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/shuttle.jpg">
                <h4>Shuttle</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>115,000 MMK</p>
            </div>
        </div>
            <h2 class="title">Basketball Products</h2>
            <div class="row">
            <div class="col-4">
                <img src="images/basketshirt.jpg">
                <h4>Jersey</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>31,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/bball.jpg">
                <h4>Basketball</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>55,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/basketshoes.jpg">
                <h4>Shoes</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>120,000 MMK</p>
            </div>
            <div class="col-4">
                <img src="images/basketpants.jpg">
                <h4>Pants</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>20,000 MMK</p>
            </div>
        </div>
        </section>
 <!-------- offer --------->
        <div class="offer">
            <div class="small-container">
                <div class="row">
                    <div class="">
                        <img src="images/logo3.jpg" class="offer-img">
                    </div>
                    <div class="col-2">
                        <p>Exclusively available on Playstore</p>
                        <h1>G9SportsStore</h1>
                        <small>Established From 2025</small>
                        <a href="" class="btn">Buy Now &#8594;</a>

                    </div>
                </div>
            </div>
        </div>
<!---------js for toggle menu--------->
    <script>
        var MenuItems = document.getElementById("MenuItems");

        MenuItems.style.maxHeight = "0px";

        function menutoggle(){
            if(MenuItems.style.maxHeight == "0px")
            {
                MenuItems.style.maxHeight = "200px";
            }
            else
            {
                MenuItems.style.maxHeight = "0px";
            }
        }
    </script>
 
</body>
</html>