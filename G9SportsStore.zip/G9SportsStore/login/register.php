<?php
session_start();
require 'database/database.php';

$errors = [];
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect form data
    $firstName = htmlspecialchars(trim($_POST["firstName"]));
    $lastName  = htmlspecialchars(trim($_POST["lastName"]));
    $email     = htmlspecialchars(trim($_POST["email"]));
    $username  = htmlspecialchars(trim($_POST["username"]));
    $phone     = htmlspecialchars(trim($_POST["phone"]));
    $password  = htmlspecialchars(trim($_POST["password"]));
    $confirmPassword = htmlspecialchars(trim($_POST["confirmPassword"]));
    $gender    = htmlspecialchars(trim($_POST["gender"]));

    // Validation
    if (empty($firstName)) $errors[] = "First name is required.";
    if (empty($lastName)) $errors[] = "Last name is required.";
    if (empty($email)) $errors[] = "Email is required.";
    if (empty($username)) $errors[] = "Username is required.";
    if (empty($phone)) $errors[] = "Phone number is required.";
    if (empty($password)) $errors[] = "Password is required.";
    if ($password !== $confirmPassword) $errors[] = "Passwords do not match.";
    if (empty($gender)) $errors[] = "Gender is required.";

    // Check for existing email/username
    $sql = "SELECT id FROM users WHERE email = ? OR username = ?";
    $stmt = mysqli_stmt_init($conn);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, "ss", $email, $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if (mysqli_num_rows($result) > 0) {
            $errors[] = "Email or username already exists.";
        }
    } else {
        $errors[] = "Database error. Please try again later.";
    }

    // Insert user if no errors
    if (count($errors) === 0) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (first_name, last_name, email, username, phone, password, gender) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_stmt_init($conn);
        if (mysqli_stmt_prepare($stmt, $sql)) {
            mysqli_stmt_bind_param($stmt, "sssssss", $firstName, $lastName, $email, $username, $phone, $hashedPassword, $gender);
            if (mysqli_stmt_execute($stmt)) {
                $success = "Registration successful! You can now <a href='login.php'>login</a>.";
            } else {
                $errors[] = "Something went wrong. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Registration Form — Bootstrap 5</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #aa4b6b, #6b6b83, #3b8d99); }
.card { max-width: 820px; margin: 40px auto; border-radius: 12px; box-shadow: 0 8px 30px rgba(16,24,40,0.08); }
.form-control:focus { box-shadow: none; }
</style>
</head>
<body>
<div class="card">
  <div class="row g-0">
    <div class="col-md-5 d-none d-md-block bg-light p-4">
      <div class="h-100 d-flex flex-column justify-content-center align-items-center">
        <h4 class="mb-1">Create your account</h4>
        <p class="text-muted text-center">Quick sign up to access all features. It's free and takes a minute.</p>
        <img src="images/logo.jpg" class="img-fluid rounded mt-3" alt="illustration">
      </div>
    </div>

    <div class="col-md-7 p-4">
      <div class="card-body">
        <h5 class="card-title mb-3">Register</h5>

        <?php if(!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul>
              <?php foreach($errors as $e) echo "<li>$e</li>"; ?>
            </ul>
          </div>
        <?php endif; ?>
        <?php if($success): ?>
          <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form id="regForm" method="post" novalidate>
          <div class="row g-3">
            <div class="col-sm-6">
              <label class="form-label">First name</label>
              <input type="text" name="firstName" class="form-control" required>
            </div>
            <div class="col-sm-6">
              <label class="form-label">Last name</label>
              <input type="text" name="lastName" class="form-control" required>
            </div>
            <div class="col-12">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Username</label>
              <input type="text" name="username" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Phone</label>
              <input type="tel" name="phone" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Password</label>
              <div class="input-group">
                <input type="password" name="password" id="password" class="form-control" minlength="8" required>
                <button class="btn btn-outline-secondary" type="button" id="togglePassword">Show</button>
              </div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Confirm Password</label>
              <input type="password" name="confirmPassword" id="confirmPassword" class="form-control" minlength="8" required>
            </div>
            <div class="col-md-6">
              <label class="form-label d-block fw-bold">Gender</label>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" value="male" checked>
                <label class="form-check-label">Male</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" value="female">
                <label class="form-check-label">Female</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" value="other">
                <label class="form-check-label">Other</label>
              </div>
            </div>
            <div class="col-12 d-flex justify-content-between align-items-center">
              <div>
                <button type="submit" class="btn btn-primary">Create account</button>
                <button type="reset" class="btn btn-outline-secondary ms-2 mt-4">Reset</button>
              </div>
              <small class="text-muted">Already have an account? <a href="login.php">Login in</a></small>
            </div>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('togglePassword').addEventListener('click', function () {
  const pwd = document.getElementById('password');
  if (pwd.type === 'password') { pwd.type = 'text'; this.textContent='Hide'; }
  else { pwd.type='password'; this.textContent='Show'; }
});
</script>
</body>
</html>
