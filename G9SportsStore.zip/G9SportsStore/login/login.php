<?php
session_start();
require 'database/database.php';

$loginError = '';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepared statement for security
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        if (password_verify($password, $user['password'])) {
            // Store user info in session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            // Redirect to main page
            header("Location: ../main.php");
            exit();
        } else {
            $loginError = "Invalid email or password.";
        }
    } else {
        $loginError = "User not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Login Form — Bootstrap 5</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #aa4b6b, #6b6b83, #3b8d99); }
.card { max-width: 420px; margin: 60px auto; border-radius: 12px; box-shadow: 0 8px 30px rgba(16,24,40,0.08); }
.form-control:focus { box-shadow: none; }
</style>
</head>
<body>
<div class="card p-4">
  <div class="card-body">
    <h4 class="card-title text-center mb-3">Login</h4>
    <p class="text-muted text-center mb-4">Enter your credentials to access your account</p>

    <?php if(!empty($loginError)): ?>
        <div class="alert alert-danger"><?php echo $loginError; ?></div>
    <?php endif; ?>

    <form method="post" id="loginForm" novalidate>
      <div class="mb-3">
        <label for="email" class="form-label">Email address</label>
        <input type="email" class="form-control" name="email" id="email" placeholder="you@example.com" required>
        <div class="invalid-feedback">Please enter a valid email address.</div>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <div class="input-group">
          <input type="password" class="form-control" name="password" id="password" minlength="8" required>
          <button class="btn btn-outline-secondary" type="button" id="togglePassword">Show</button>
        </div>
        <div class="invalid-feedback">Password must be at least 8 characters.</div>
      </div>

      <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="remember">
        <label class="form-check-label" for="remember">Remember me</label>
      </div>

      <div class="d-grid">
        <button type="submit" name="login" class="btn btn-primary">Login</button>
      </div>

      <div class="mt-3 text-center">
        <small class="text-muted">Don't have an account? <a href="register.php">Register</a></small>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Bootstrap validation
(function () {
  'use strict'
  const form = document.getElementById('loginForm');
  form.addEventListener('submit', function (event) {
    if (!form.checkValidity()) {
      event.preventDefault();
      event.stopPropagation();
    }
    form.classList.add('was-validated');
  }, false)
})();

// Toggle password visibility
document.getElementById('togglePassword').addEventListener('click', function () {
  const pwd = document.getElementById('password');
  if (pwd.type === 'password') {
    pwd.type = 'text';
    this.textContent = 'Hide';
  } else {
    pwd.type = 'password';
    this.textContent = 'Show';
  }
});
</script>
</body>
</html>
