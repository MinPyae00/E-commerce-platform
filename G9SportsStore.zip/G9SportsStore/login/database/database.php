<?php
$hostname = "localhost";
$username = "root"; 
$password = "";
$database = "myapp";

$conn = new mysqli($hostname, $username, $password, $database);
if (!$conn) {
    die("Connection failed:");
}